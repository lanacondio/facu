export class Product {
    id: number;
    description: string;
    title: string;
    photo_url: string;    
	stock: number;    
	category_id:number;
}