"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product = (function () {
    function Product() {    	
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=user.js.map