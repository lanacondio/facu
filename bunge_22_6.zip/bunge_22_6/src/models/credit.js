"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Credit = (function () {
    function Credit() {    	
    }
    return Credit;
}());
exports.Credit = Credit;
//# sourceMappingURL=user.js.map