"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Category = (function () {
    function Category() {    	
    }
    return Category;
}());
exports.Category = Category;
//# sourceMappingURL=user.js.map