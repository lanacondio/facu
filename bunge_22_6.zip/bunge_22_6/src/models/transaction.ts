export class Transaction {
    id: number;
    date: date;
    product_id: number;
    user_id: number;
}