"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Transaction = (function () {
    function Transaction() {    	
    }
    return Transaction;
}());
exports.Transaction = Transaction;
//# sourceMappingURL=user.js.map