export class Category {
    id: number;
    event: Evt;
    description: string;
    available_products: Product[];
    selected_products: Product[];
    available_credit: number;

 }