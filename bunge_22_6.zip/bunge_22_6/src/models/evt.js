"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventModel = (function () {
    function EventModel() {    	
    }
    return EventModel;
}());
exports.EventModel = EventModel;
//# sourceMappingURL=user.js.map