export class Evt {
    id: number;
    description: string;
    banner_url:string;
    start_date: date;
    end_date: date;    	
}