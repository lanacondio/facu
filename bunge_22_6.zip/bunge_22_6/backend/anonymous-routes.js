var express = require('express');
   

var app = module.exports = express.Router();

app.get('/api/random-quote', function(req, res) {
  
});
