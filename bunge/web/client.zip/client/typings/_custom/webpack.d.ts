declare var require: any;
declare var __filename: string;
declare var __dirname: string;
declare var global: any;