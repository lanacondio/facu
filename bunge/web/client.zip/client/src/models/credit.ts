export class Credit {
    id: number;
    user_id: number;
    quantity: number;
    category_id: number;    
}