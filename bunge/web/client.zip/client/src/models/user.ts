export class User {
    id: number;
    file: string;
    password: string;
    category_id: number;    
}