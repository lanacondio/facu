export class Product {
    id: number;
    description: string;
    photo_url: string;
    category_id: number;    
}