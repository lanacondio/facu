import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { AuthHttp } from 'angular2-jwt';
import { contentHeaders } from '../common/headers';
import { User } from '../models/index';
import { Credit } from '../models/index';
import { Product } from '../models/index';

const styles = require('./home.css');
const template = require('./home.html');


@Component({
  selector: 'home',
  template: template,
  styles: [ styles ]
})
export class Home {
  jwt: string;
  decodedJwt: string;
  user_id: string;
  response: string;
  api: string;
  catalog: string;

  products: Products[] = [];
  credits: Credits[] = [];
  
  constructor(public router: Router, public http: Http, public authHttp: AuthHttp) {
  
    products: Products[] = [];
    credits: Credits[] = [];  
    this.products= [];
    this.credits= [];  
     this.usr_id = localStorage.getItem('id_usr');
    this.decodedJwt = this.jwt && window.jwt_decode(this.jwt);    
    
  }

  logout() {
    localStorage.removeItem('id_usr');
    this.router.navigate(['login']);
  }

  viewCatalog() {
    
    let user_id = localStorage.getItem('id_usr');
    let body = JSON.stringify({user_id});        
    this.authHttp.post('http://localhost:3001/credits', body, { headers: contentHeaders }) 
      .subscribe(  
        response => {
          this.credits = response.json().credits;         
          let credits = response.json().credits;          
          if(!credits){
            alert("el usuario no tiene más creditos");  
          }
          else{
            this._populateProducts();              
          }},
          error => {
            alert(error.text());
            console.log(error.text());
          }

        );    

  }

  callSecuredApi() {    
    debugger;
    this._callApi('Secured', 'http://localhost:3001/api/protected/random-quote');
  }

  _populateProducts(){
    
    this.credits.forEach((credit,index) =>{           
      debugger;
      let category_id = credit.category_id.toString();
      let body = JSON.stringify({category_id});    
      this.http.post('http://localhost:3001/productsbycategory', body, { headers: contentHeaders })
      .subscribe(
      response => {                
        debugger;
          let productsr = response.json().products;          
          productsr.forEach((product) => {
          this.products.push(
            {id: product.id,
            descripton: product.descripton, 
            photo_url: product.photo_url, 
            stock:product.stock,
            category_id:product.category_id}  
          );          
          });
          },
          error => {
            alert(error.text());
            console.log(error.text());
            });
              
      });      
 
  }

  _callApi(type, url) {
    debugger
    this.response = null;
    if (type === 'Anonymous') {
      // For non-protected routes, just use Http
      this.http.get(url)
        .subscribe(
          response => this.response = response.text(),
          error => this.response = error.text()
        );
    }
    if (type === 'Secured') {
      // For protected routes, use AuthHttp
      this.authHttp.get(url)
        .subscribe(
          response => this.response = response.text(),
          error => this.response = error.text()
        );
    }
  }
}
